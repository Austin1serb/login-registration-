package com.austin.loginandregistration.services;

import java.util.Optional;

import org.mindrot.jbcrypt.BCrypt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.validation.BindingResult;

import com.austin.loginandregistration.models.LoginUser;
import com.austin.loginandregistration.models.User;
import com.austin.loginandregistration.repositories.UserRepository;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public User registerUser(User user) {
        //check if user already exists
        // if (userRepository.findByEmail(user.getEmail()).isPresent()) {
        //     result.rejectValue("email", "Unique", "This email is already in use!");
        //     return null;

        // }
        //Hash the password and save the user to the database
        String hashed = BCrypt.hashpw(user.getPassword(), BCrypt.gensalt());
        user.setPassword(hashed);
        return userRepository.save(user);
    }

    public User getUser(String email) {
        Optional<User> potentialUser = userRepository.findByEmail(email);
        return potentialUser.isPresent() ? potentialUser.get() : null;
    }

    public User getUser(Long id) {
        Optional<User> potentialUser = userRepository.findById(id);
        return potentialUser.isPresent() ? potentialUser.get() : null;
    }

    public User login(LoginUser loginUser, BindingResult result) {
        if (result.hasErrors()) {
            return null;
        }
        User existingUser = this.getUser(loginUser.getEmail());
        if (existingUser == null) {
            result.rejectValue("email", "invalid credentials", "Invalid Username or email!");
            return null;
        }
        if (!BCrypt.checkpw(loginUser.getPassword(), existingUser.getPassword())) {
            result.rejectValue("password", "invalid credentials", "Invalid Username or email!");
            return null;
        }
        return existingUser;
    }

}
