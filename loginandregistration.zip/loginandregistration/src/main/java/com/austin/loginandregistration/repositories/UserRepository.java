package com.austin.loginandregistration.repositories;

import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Controller;

import com.austin.loginandregistration.models.User;

@Controller
public interface UserRepository extends CrudRepository<User, Long> {

    Optional<User> findByEmail(String email);

}
